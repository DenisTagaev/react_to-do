import React from 'react';

export default function AddHelper() {
  return (
    <div className="helperOutletContainer">
      <h3 className="helperOutletHeading">add-helper page</h3>
      <p className="helperOutletInstructions">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mi
        turpis, cursus non turpis ac, tincidunt suscipit mi. Fusce finibus
        turpis tempus maximus consectetur. Vivamus faucibus dui nisl, vitae
        pellentesque mi euismod in. Vestibulum ut consectetur dui. Vivamus
        vulputate arcu risus, vel rhoncus neque ornare ac. Proin lobortis elit
        ut tellus congue feugiat. Suspendisse pellentesque libero et molestie
        rhoncus. Nam tempor lorem pulvinar lectus finibus imperdiet. Duis rutrum
        molestie libero, et rutrum nisl. Maecenas est mi, sagittis et turpis at,
        sagittis posuere tortor. Suspendisse in ullamcorper arcu. Maecenas
        faucibus magna quis sollicitudin commodo. Sed at mauris ultrices,
        volutpat ex id, luctus diam.
      </p>
    </div>
  );
}
